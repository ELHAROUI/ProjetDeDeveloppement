Objectif : Représentation des éléments du jeu.

=> Représentation des différents types de cartes Age à l'exception des batiments commerciaux et militaires et des guildes.
On considère l'existence d'une seule merveille pour le moment. Le plateau est donc le meme pour chaque joueur.

Représentation  de la mise en jeu d'une carte : Selon le type de la carte , il  y aura attribution de points de victoires ou de ressources.
Chaque plateau correspond à un joueur.


Fonctionnalités implémentées :

   Implémentation de la mise en jeu d'une carte: Attribution de points de victoire ou de ressources à un plateau lorsque l'action est de jouer une carte. 
   
